﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Anntgc00492University.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
