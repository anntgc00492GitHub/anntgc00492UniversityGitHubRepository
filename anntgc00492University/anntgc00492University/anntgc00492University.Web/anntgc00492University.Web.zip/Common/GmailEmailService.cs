﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace anntgc00492University.Web.Common
{
    public class GmailEmailService
    {

    }
}